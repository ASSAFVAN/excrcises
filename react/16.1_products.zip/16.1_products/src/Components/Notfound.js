import React from "react";

export default function Notfound() {
  return <div>404 Page not found</div>;
}
