import React from "react";
import "./App.css";
import Button from "./Components/Button";

class App extends React.Component {
  render() {
    return (
      <div>
        <Button />
      </div>
    );
  }
}

export default App;
