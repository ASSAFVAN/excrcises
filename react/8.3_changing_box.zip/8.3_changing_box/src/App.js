import React from "react";
// import "./App.css";
import ChangeBox from "./Components/ChangingBox";

class App extends React.Component {
  render() {
    return (
      <div>
        <ChangeBox />
      </div>
    );
  }
}

export default App;
